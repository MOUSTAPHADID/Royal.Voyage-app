import { ScrollView, Text, View, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";

export default function VisasScreen() {
  const colors = useColors();
  const router = useRouter();
  const [isRTL] = useState(true);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Header */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 12 }}>
            <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
          </Pressable>
          <Text style={{ fontSize: 28, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
            {isRTL ? "التأشيرات" : "Visas"}
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted }}>
            {isRTL ? "استخرج تأشيرتك بسهولة وسرعة" : "Get your visa easily and quickly"}
          </Text>
        </View>

        {/* Coming Soon Message */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 40, alignItems: "center", gap: 16 }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: colors.primary + "20",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <MaterialIcons name="approval" size={40} color={colors.primary} />
          </View>
          <Text style={{ fontSize: 18, fontWeight: "700", color: colors.foreground, textAlign: "center" }}>
            {isRTL ? "خدمة التأشيرات قريباً" : "Visa Service Coming Soon"}
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center", lineHeight: 20 }}>
            {isRTL
              ? "نحن نعمل على تطوير خدمة التأشيرات الشاملة. ستتمكن قريباً من استخراج تأشيرتك مباشرة من التطبيق."
              : "We're developing a comprehensive visa service. You'll soon be able to apply for your visa directly from the app."}
          </Text>
        </View>

        {/* Features Preview */}
        <View style={{ paddingHorizontal: 20, gap: 12, marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
            {isRTL ? "المميزات القادمة" : "Coming Features"}
          </Text>

          {[
            { icon: "description", title: isRTL ? "طلب سهل" : "Easy Application", desc: isRTL ? "نموذج بسيط وسريع" : "Simple & fast form" },
            { icon: "cloud-upload", title: isRTL ? "رفع المستندات" : "Document Upload", desc: isRTL ? "رفع آمن للمستندات" : "Secure document upload" },
            { icon: "track-changes", title: isRTL ? "تتبع الحالة" : "Track Status", desc: isRTL ? "تحديثات فورية" : "Real-time updates" },
            { icon: "notifications-active", title: isRTL ? "إشعارات" : "Notifications", desc: isRTL ? "تنبيهات فورية" : "Instant notifications" },
          ].map((feature, idx) => (
            <View
              key={idx}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                paddingHorizontal: 12,
                paddingVertical: 12,
                borderRadius: 12,
                backgroundColor: colors.surface,
              }}
            >
              <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primary + "20", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={feature.icon as any} size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{feature.title}</Text>
                <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{feature.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Contact Support */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Pressable
            style={{
              paddingHorizontal: 16,
              paddingVertical: 12,
              borderRadius: 12,
              backgroundColor: colors.primary + "15",
              borderWidth: 1.5,
              borderColor: colors.primary + "40",
              alignItems: "center",
              gap: 8,
            }}
          >
            <MaterialIcons name="mail" size={20} color={colors.primary} />
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.primary }}>
              {isRTL ? "تواصل معنا للمزيد" : "Contact us for more info"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
