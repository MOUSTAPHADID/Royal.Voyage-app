import { ScrollView, Text, View, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useState } from "react";

export default function InsuranceScreen() {
  const colors = useColors();
  const router = useRouter();
  const [isRTL] = useState(true);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Header */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16 }}>
          <Pressable onPress={() => router.back()} style={{ marginBottom: 12 }}>
            <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
          </Pressable>
          <Text style={{ fontSize: 28, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
            {isRTL ? "التأمين" : "Insurance"}
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted }}>
            {isRTL ? "حماية شاملة لرحلتك" : "Complete protection for your trip"}
          </Text>
        </View>

        {/* Coming Soon Message */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 40, alignItems: "center", gap: 16 }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: colors.primary + "20",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <MaterialIcons name="security" size={40} color={colors.primary} />
          </View>
          <Text style={{ fontSize: 18, fontWeight: "700", color: colors.foreground, textAlign: "center" }}>
            {isRTL ? "خدمة التأمين قريباً" : "Insurance Service Coming Soon"}
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center", lineHeight: 20 }}>
            {isRTL
              ? "نحن نعمل على تطوير خدمة التأمين الشاملة. ستتمكن قريباً من اختيار خطة تأمين مناسبة لرحلتك."
              : "We're developing comprehensive insurance coverage. You'll soon be able to choose the right insurance plan for your trip."}
          </Text>
        </View>

        {/* Insurance Types Preview */}
        <View style={{ paddingHorizontal: 20, gap: 12, marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
            {isRTL ? "أنواع التأمين" : "Insurance Types"}
          </Text>

          {[
            { icon: "health-and-safety", title: isRTL ? "تأمين صحي" : "Health Insurance", desc: isRTL ? "تغطية طبية شاملة" : "Complete medical coverage" },
            { icon: "luggage", title: isRTL ? "تأمين الأمتعة" : "Baggage Insurance", desc: isRTL ? "حماية أمتعتك" : "Protect your luggage" },
            { icon: "flight-takeoff", title: isRTL ? "تأمين الرحلة" : "Trip Insurance", desc: isRTL ? "حماية استثمارك" : "Protect your investment" },
            { icon: "cancel", title: isRTL ? "تأمين الإلغاء" : "Cancellation Insurance", desc: isRTL ? "استرجاع أموالك" : "Get refunded if cancelled" },
          ].map((insuranceType, idx) => (
            <View
              key={idx}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                paddingHorizontal: 12,
                paddingVertical: 12,
                borderRadius: 12,
                backgroundColor: colors.surface,
              }}
            >
              <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primary + "20", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={insuranceType.icon as any} size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{insuranceType.title}</Text>
                <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{insuranceType.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Why Choose Us */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground, marginBottom: 12 }}>
            {isRTL ? "لماذا تختارنا" : "Why Choose Us"}
          </Text>
          <View style={{ paddingHorizontal: 12, paddingVertical: 12, borderRadius: 12, backgroundColor: colors.surface, gap: 8 }}>
            <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 20 }}>
              ✓ {isRTL ? "أسعار تنافسية" : "Competitive prices"}
            </Text>
            <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 20 }}>
              ✓ {isRTL ? "تغطية شاملة" : "Comprehensive coverage"}
            </Text>
            <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 20 }}>
              ✓ {isRTL ? "دعم فوري 24/7" : "24/7 support"}
            </Text>
            <Text style={{ fontSize: 13, color: colors.foreground, lineHeight: 20 }}>
              ✓ {isRTL ? "معالجة المطالبات السريعة" : "Fast claim processing"}
            </Text>
          </View>
        </View>

        {/* Contact Support */}
        <View style={{ paddingHorizontal: 20, marginBottom: 24 }}>
          <Pressable
            style={{
              paddingHorizontal: 16,
              paddingVertical: 12,
              borderRadius: 12,
              backgroundColor: colors.primary + "15",
              borderWidth: 1.5,
              borderColor: colors.primary + "40",
              alignItems: "center",
              gap: 8,
            }}
          >
            <MaterialIcons name="mail" size={20} color={colors.primary} />
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.primary }}>
              {isRTL ? "تواصل معنا للمزيد" : "Contact us for more info"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
