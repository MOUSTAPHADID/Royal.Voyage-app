import "./load-env.js";
import { authenticator } from "otplib";
import { createEmployee, getEmployeeByEmail, updateEmployee } from "../server/pg-admin-db";
import { sendEmployeeWelcomeEmail } from "../server/email";
import { EmailService } from "../server/notifications/email";

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "angolamirlda@gmail.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "moustapha@@@@";
const ADMIN_NAME = process.env.ADMIN_NAME || "Moustapha Admin";
const ADMIN_AUTHENTICATOR_SECRET = process.env.ADMIN_AUTHENTICATOR_SECRET || authenticator.generateSecret();
const APP_NAME = "Royal Voyage Admin";

async function notifyAdmin() {
  const otpauthUrl = authenticator.keyuri(ADMIN_EMAIL, APP_NAME, ADMIN_AUTHENTICATOR_SECRET);
  const html = `
    <div style="font-family:Arial,sans-serif;line-height:1.7;color:#0B2D46">
      <h2>Royal Voyage Admin account</h2>
      <p>Your admin account has been prepared.</p>
      <ul>
        <li><strong>Email:</strong> ${ADMIN_EMAIL}</li>
        <li><strong>Temporary password:</strong> ${ADMIN_PASSWORD}</li>
      </ul>
      <p><strong>Authenticator setup:</strong></p>
      <p>Add this secret to Google Authenticator, Microsoft Authenticator, Authy, or 1Password:</p>
      <pre style="background:#f3f4f6;padding:12px;border-radius:8px">${ADMIN_AUTHENTICATOR_SECRET}</pre>
      <p>OTP Auth URL:</p>
      <pre style="white-space:pre-wrap;background:#f3f4f6;padding:12px;border-radius:8px">${otpauthUrl}</pre>
      <p style="color:#b45309"><strong>Important:</strong> Change the password immediately after first login.</p>
    </div>`;

  await EmailService.sendEmail({
    to: ADMIN_EMAIL,
    subject: "Royal Voyage Admin login and verification setup",
    html,
    text: `Royal Voyage Admin
Email: ${ADMIN_EMAIL}
Temporary password: ${ADMIN_PASSWORD}
Authenticator secret: ${ADMIN_AUTHENTICATOR_SECRET}
OTP Auth URL: ${otpauthUrl}`,
  }).catch(() => undefined);

  await sendEmployeeWelcomeEmail({
    fullName: ADMIN_NAME,
    email: ADMIN_EMAIL,
    password: ADMIN_PASSWORD,
    role: "manager",
    department: "Administration",
  }).catch(() => false);
}

async function main() {
  const existing = await getEmployeeByEmail(ADMIN_EMAIL);
  if (existing) {
    await updateEmployee(existing.id, {
      fullName: ADMIN_NAME,
      password: ADMIN_PASSWORD,
      role: "manager",
      department: "Administration",
      notes: "Primary Royal Voyage admin account. Password reset by create-admin script.",
      status: "active",
    });
    console.log("✅ Admin updated successfully");
  } else {
    const id = await createEmployee({
      fullName: ADMIN_NAME,
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      role: "manager",
      department: "Administration",
      notes: "Primary Royal Voyage admin account created by create-admin script.",
    });
    console.log(`✅ Admin created successfully. ID: ${id}`);
  }

  await notifyAdmin();

  console.log("\nAdmin login:");
  console.log(`  Email: ${ADMIN_EMAIL}`);
  console.log(`  Temporary password: ${ADMIN_PASSWORD}`);
  console.log("\nAuthenticator:");
  console.log(`  ADMIN_AUTHENTICATOR_SECRET=${ADMIN_AUTHENTICATOR_SECRET}`);
  console.log("\nAdd these env vars on the API server for 2FA:");
  console.log("  ADMIN_2FA_REQUIRED=true");
  console.log(`  ADMIN_LOGIN_EMAIL=${ADMIN_EMAIL}`);
  console.log(`  ADMIN_AUTHENTICATOR_SECRET=${ADMIN_AUTHENTICATOR_SECRET}`);
  console.log("\nRun with: pnpm create-admin");
}

main().catch((error) => {
  console.error("❌ Failed to create/update admin:", error);
  process.exit(1);
});
