# Royal Voyage Admin login setup

## Admin account

Requested admin account:

- Email: `angolamirlda@gmail.com`
- Temporary password: `moustapha@@@@`

Change this password immediately after first login.

## Create or update the admin account

Run from the project folder:

```bash
pnpm create-admin
```

This runs:

```bash
pnpm tsx scripts/create-admin.ts
```

The script will create or update the admin employee and print an Authenticator secret.

## Email verification

Admin login supports an email verification code. Configure SMTP in the API server environment:

```env
SMTP_HOST=...
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...
EMAIL_FROM=Royal Voyage <no-reply@royalvoyage.online>
```

When the admin enters the correct email and password, the API sends a 6-digit code to `angolamirlda@gmail.com`.

## Authenticator app

Admin login also supports Google Authenticator / Microsoft Authenticator / Authy.

After running:

```bash
pnpm create-admin
```

Copy the printed value into your server environment:

```env
ADMIN_2FA_REQUIRED=true
ADMIN_LOGIN_EMAIL=angolamirlda@gmail.com
ADMIN_AUTHENTICATOR_SECRET=the-secret-printed-by-the-script
```

Then restart the API server.

## Important security notes

- Do not commit real `.env` files to GitHub.
- Use a strong `ADMIN_SESSION_SECRET` in production.
- Change `moustapha@@@@` after first login.
- Keep the Authenticator secret private.
