# Royal Voyage — Multilingual + No Fake Data Update

## Languages added/cleaned
- Arabic
- English
- French
- Portuguese

## Main fixes
- Partner registration now supports Arabic, English, French, and Portuguese.
- Business/company registration now supports Arabic, English, French, and Portuguese.
- Payment methods screen includes Portuguese labels and descriptions.
- Edit profile screen includes French and Portuguese labels and alerts.

## Fake data removed from home
- Fake customer avatars and reviews were removed.
- Fake popular activities were removed.
- Fake destination display was replaced with a live-data notice.
- eSIM still shows no fake prices and no fake plans.

## API status
Royal Voyage API code exists in the project under `server/` and app calls are designed around `/api/trpc` through `lib/trpc.ts`.
It still requires production deployment and `.env` values to be truly live.
