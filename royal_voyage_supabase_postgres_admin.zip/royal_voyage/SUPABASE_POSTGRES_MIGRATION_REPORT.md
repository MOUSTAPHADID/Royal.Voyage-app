# Royal Voyage — Supabase PostgreSQL Admin Migration

This ZIP adds Supabase PostgreSQL support for the Royal Voyage admin login path without breaking the existing MySQL code.

## What changed
- Added `server/pg-admin-db.ts`.
- `DATABASE_URL=postgresql://...` or `postgres://...` now uses Supabase PostgreSQL for admin employees and login logs.
- MySQL still works if `DATABASE_URL=mysql://...`.
- Updated `server/routers.ts` so admin login/employee pages use the new PostgreSQL-compatible helper.
- Updated `scripts/create-admin.ts` to create/update the admin through the PostgreSQL-compatible helper.
- Added `postgres` dependency.
- Auto-creates these tables when needed:
  - `employees`
  - `login_logs`

## Required .env
Do not upload `.env` to GitHub.

```env
DATABASE_URL=postgresql://postgres.xxxxx:YOUR_PASSWORD@aws-0-xxxx.pooler.supabase.com:6543/postgres
ADMIN_EMAIL=angolamirlda@gmail.com
ADMIN_PASSWORD=moustapha@@@@
```

Use Supabase **Transaction pooler** if possible. It normally uses port `6543`.

## Commands
```bash
cd royal_voyage
pnpm install
pnpm create-admin
pnpm check
eas build --platform android --profile admin-internal
```

## Scope
This migration focuses on admin login, employee management, and login logs. Other operational tables may still need a complete PostgreSQL schema migration later.
