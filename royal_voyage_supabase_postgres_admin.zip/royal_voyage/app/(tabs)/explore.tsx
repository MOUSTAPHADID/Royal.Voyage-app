import { View, Text, Pressable, StyleSheet, Linking } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useTranslation } from "@/lib/i18n";

export default function ExploreScreen() {
  const colors = useColors();
  const { language, isRTL } = useTranslation();
  const L = (ar: string, en: string, fr: string, pt: string) =>
    language === "ar" ? ar : language === "fr" ? fr : language === "pt" ? pt : en;
  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <View style={[styles.header, { backgroundColor: colors.primary }]}> 
        <Text style={styles.headerTitle}>{L("استكشف", "Explore", "Explorer", "Explorar")}</Text>
        <Text style={styles.headerSub}>{L("لا نعرض وجهات أو أسعارًا وهمية", "No fake destinations or prices", "Aucune destination ni prix fictifs", "Sem destinos ou preços fictícios")}</Text>
      </View>
      <View style={[styles.body, { backgroundColor: colors.background }]}> 
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: "#D4AF37" }]}> 
          <IconSymbol name="globe" size={34} color={colors.primary} />
          <Text style={[styles.title, { color: colors.foreground, textAlign: isRTL ? "right" : "left" }]}>{L("الوجهات الحقيقية قريبًا", "Real destinations coming soon", "Destinations réelles bientôt", "Destinos reais em breve")}</Text>
          <Text style={[styles.text, { color: colors.muted, textAlign: isRTL ? "right" : "left" }]}>
            {L(
              "ستظهر الوجهات والعروض من Royal Voyage API بعد نشر السيرفر وربط مصادر البيانات. يمكنك التواصل معنا الآن لأي وجهة.",
              "Destinations and offers will appear from the Royal Voyage API after backend deployment and data-source connection. Contact us now for any destination.",
              "Les destinations et offres viendront de l’API Royal Voyage après le déploiement du backend et la connexion des sources. Contactez-nous pour toute destination.",
              "Os destinos e ofertas aparecerão pela API Royal Voyage após publicar o backend e ligar as fontes de dados. Contacte-nos para qualquer destino."
            )}
          </Text>
          <Pressable style={[styles.btn, { backgroundColor: colors.primary }]} onPress={() => Linking.openURL("https://wa.me/22233700000")}>
            <Text style={styles.btnText}>{L("تواصل معنا", "Contact us", "Nous contacter", "Contacte-nos")}</Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 24, gap: 8 },
  headerTitle: { color: "#FFFFFF", fontSize: 24, fontWeight: "800" },
  headerSub: { color: "rgba(255,255,255,0.75)", fontSize: 14 },
  body: { flex: 1, padding: 20 },
  card: { borderWidth: 1.3, borderRadius: 20, padding: 22, gap: 14 },
  title: { fontSize: 20, fontWeight: "900" },
  text: { fontSize: 14, lineHeight: 22 },
  btn: { borderRadius: 16, paddingVertical: 15, alignItems: "center", marginTop: 8 },
  btnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
});
