import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useApp } from "@/lib/app-context";
import { useTranslation, useI18n } from "@/lib/i18n";
import { IconSymbol } from "@/components/ui/icon-symbol";

export default function EditProfileScreen() {
  const router = useRouter();
  const colors = useColors();
  const { user, updateUser } = useApp();
  const { t } = useTranslation();
  const { language } = useI18n();
  const L = (ar: string, en: string, fr: string, pt: string) => language === "ar" ? ar : language === "fr" ? fr : language === "pt" ? pt : en;

  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [nationality, setNationality] = useState(user?.nationality ?? "");
  const [passportNumber, setPassportNumber] = useState(user?.passportNumber ?? "");
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert(
        L("خطأ", "Error", "Erreur", "Erro"),
        L("الاسم مطلوب", "Name is required", "Le nom est requis", "O nome é obrigatório")
      );
      return;
    }
    setIsSaving(true);
    try {
      updateUser({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        nationality: nationality.trim(),
        passportNumber: passportNumber.trim(),
      });
      Alert.alert(
        L("تم الحفظ", "Saved", "Enregistré", "Guardado"),
        L("تم تحديث بياناتك بنجاح", "Your profile has been updated", "Votre profil a été mis à jour", "O seu perfil foi atualizado"),
        [{ text: "OK", onPress: () => router.back() }]
      );
    } catch {
      Alert.alert(
        L("خطأ", "Error", "Erreur", "Erro"),
        L("حدث خطأ أثناء الحفظ", "An error occurred while saving", "Une erreur est survenue pendant l’enregistrement", "Ocorreu um erro ao guardar")
      );
    } finally {
      setIsSaving(false);
    }
  };

  const fields = [
    {
      label: L("الاسم الكامل", "Full Name", "Nom complet", "Nome completo"),
      value: name,
      onChange: setName,
      placeholder: L("أدخل اسمك الكامل", "Enter your full name", "Saisissez votre nom complet", "Introduza o seu nome completo"),
      icon: "person.fill",
      required: true,
      keyboardType: "default" as const,
    },
    {
      label: L("رقم الهاتف", "Phone Number", "Téléphone", "Telefone"),
      value: phone,
      onChange: setPhone,
      placeholder: "+222 XX XX XX XX",
      icon: "phone.fill",
      required: false,
      keyboardType: "phone-pad" as const,
    },
    {
      label: L("البريد الإلكتروني", "Email", "E-mail", "E-mail"),
      value: email,
      onChange: setEmail,
      placeholder: "you@example.com",
      icon: "envelope.fill",
      required: false,
      keyboardType: "email-address" as const,
    },
    {
      label: L("الجنسية", "Nationality", "Nationalité", "Nacionalidade"),
      value: nationality,
      onChange: setNationality,
      placeholder: L("مثال: موريتانية", "e.g. Mauritanian", "ex. Mauritanienne", "ex.: Mauritana"),
      icon: "globe",
      required: false,
      keyboardType: "default" as const,
    },
    {
      label: L("رقم جواز السفر", "Passport Number", "Numéro de passeport", "Número do passaporte"),
      value: passportNumber,
      onChange: setPassportNumber,
      placeholder: L("رقم الجواز", "Passport number", "Numéro du passeport", "Número do passaporte"),
      icon: "doc.text.fill",
      required: false,
      keyboardType: "default" as const,
    },
  ];

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <IconSymbol name="chevron.left.forwardslash.chevron.right" size={20} color="#FFF" />
            <Text style={styles.backText}>
              {L("رجوع", "Back", "Retour", "Voltar")}
            </Text>
          </Pressable>
          <Text style={styles.headerTitle}>
            {L("تعديل الملف الشخصي", "Edit Profile", "Modifier le profil", "Editar perfil")}
          </Text>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Avatar */}
          <View style={styles.avatarSection}>
            <View style={[styles.avatar, { backgroundColor: colors.primary + "20" }]}>
              <Text style={[styles.avatarText, { color: colors.primary }]}>
                {name?.charAt(0)?.toUpperCase() ?? "?"}
              </Text>
            </View>
          </View>

          {/* Fields */}
          {fields.map((field) => (
            <View key={field.label} style={styles.fieldGroup}>
              <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
                {field.label} {field.required ? "*" : ""}
              </Text>
              <View style={[styles.inputRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <IconSymbol name={field.icon as any} size={18} color={colors.muted} />
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  placeholder={field.placeholder}
                  placeholderTextColor={colors.muted}
                  value={field.value}
                  onChangeText={field.onChange}
                  keyboardType={field.keyboardType}
                  autoCapitalize={field.keyboardType === "email-address" ? "none" : "words"}
                  autoCorrect={false}
                />
              </View>
            </View>
          ))}

          {/* Save Button */}
          <Pressable
            style={({ pressed }) => [
              styles.saveBtn,
              { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={handleSave}
            disabled={isSaving}
          >
            <Text style={styles.saveBtnText}>
              {isSaving
                ? (L("جاري الحفظ...", "Saving...", "Enregistrement...", "A guardar..."))
                : (L("حفظ التعديلات", "Save Changes", "Enregistrer", "Guardar alterações"))}
            </Text>
          </Pressable>

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    flexDirection: "column",
    gap: 8,
  },
  backBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  backText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "500",
  },
  headerTitle: {
    color: "#FFF",
    fontSize: 22,
    fontWeight: "700",
  },
  scrollContent: {
    padding: 20,
  },
  avatarSection: {
    alignItems: "center",
    marginBottom: 28,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontSize: 32,
    fontWeight: "700",
  },
  fieldGroup: {
    marginBottom: 18,
  },
  fieldLabel: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 8,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    gap: 10,
  },
  input: {
    flex: 1,
    paddingVertical: 14,
    fontSize: 16,
  },
  saveBtn: {
    paddingVertical: 18,
    borderRadius: 14,
    alignItems: "center",
    marginTop: 12,
  },
  saveBtnText: {
    color: "#FFF",
    fontSize: 17,
    fontWeight: "700",
  },
});
