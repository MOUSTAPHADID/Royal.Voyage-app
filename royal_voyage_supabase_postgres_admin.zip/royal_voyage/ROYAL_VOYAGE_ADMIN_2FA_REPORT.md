# Royal Voyage Admin 2FA Update Report

## Added

- Admin account creation/update script now targets `angolamirlda@gmail.com`.
- Temporary password set to `moustapha@@@@` as requested.
- Added package script: `pnpm create-admin`.
- Admin login supports a second verification step.
- Verification can be completed by email OTP or Authenticator app code.
- Added `.env.admin.example`.
- Added `ADMIN_LOGIN_SECURITY_SETUP.md`.

## Run

```bash
pnpm create-admin
```

## Build

```bash
pnpm install
pnpm check
eas build --platform android --profile admin-internal
```
