// @ts-nocheck
import postgres from "postgres";
import * as crypto from "crypto";
import type { Employee, LoginLog } from "../drizzle/schema";
import * as mysqlDb from "./db";

type EmployeeRole = "manager" | "accountant" | "booking_agent" | "support";
type EmployeeStatus = "active" | "inactive";

let pgClient: ReturnType<typeof postgres> | null = null;

function isPostgresUrl() {
  return /^postgres(ql)?:\/\//i.test(process.env.DATABASE_URL || "");
}

function pg() {
  if (!isPostgresUrl()) return null;
  if (!pgClient) {
    pgClient = postgres(process.env.DATABASE_URL!, {
      max: 3,
      idle_timeout: 20,
      connect_timeout: 20,
      ssl: process.env.DATABASE_URL!.includes("supabase") ? "require" : undefined,
    });
  }
  return pgClient;
}

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

export function verifyPassword(password: string, hash: string): boolean {
  if (!isPostgresUrl()) return mysqlDb.verifyPassword(password, hash);
  return hashPassword(password) === hash;
}

async function ensureTables() {
  const db = pg();
  if (!db) return;
  await db`create table if not exists employees (
    id serial primary key,
    "fullName" varchar(255) not null,
    email varchar(320) not null unique,
    phone varchar(32),
    "passwordHash" varchar(255) not null,
    role varchar(32) not null default 'support',
    permissions text,
    status varchar(32) not null default 'active',
    department varchar(128),
    "hireDate" timestamptz,
    "lastLogin" timestamptz,
    notes text,
    "createdAt" timestamptz not null default now(),
    "updatedAt" timestamptz not null default now()
  )`;
  await db`create table if not exists login_logs (
    id serial primary key,
    identifier varchar(320) not null,
    "accountType" varchar(32) not null default 'admin',
    success boolean not null default false,
    "ipAddress" varchar(64),
    "userAgent" varchar(512),
    "failureReason" varchar(255),
    "createdAt" timestamptz not null default now()
  )`;
}

function employee(row: any): Employee {
  return row as Employee;
}

function log(row: any): LoginLog {
  return row as LoginLog;
}

export async function getEmployees(): Promise<Employee[]> {
  if (!isPostgresUrl()) return mysqlDb.getEmployees();
  const db = pg();
  if (!db) return [];
  await ensureTables();
  const rows = await db`select * from employees order by "createdAt" desc`;
  return rows.map(employee);
}

export async function getEmployeeById(id: number): Promise<Employee | undefined> {
  if (!isPostgresUrl()) return mysqlDb.getEmployeeById(id);
  const db = pg();
  if (!db) return undefined;
  await ensureTables();
  const rows = await db`select * from employees where id = ${id} limit 1`;
  return rows[0] ? employee(rows[0]) : undefined;
}

export async function getEmployeeByEmail(email: string): Promise<Employee | undefined> {
  if (!isPostgresUrl()) return mysqlDb.getEmployeeByEmail(email);
  const db = pg();
  if (!db) return undefined;
  await ensureTables();
  const rows = await db`select * from employees where lower(email) = lower(${email}) limit 1`;
  return rows[0] ? employee(rows[0]) : undefined;
}

export async function createEmployee(data: {
  fullName: string;
  email: string;
  phone?: string;
  password: string;
  role: EmployeeRole;
  permissions?: string;
  department?: string;
  hireDate?: Date;
  notes?: string;
}): Promise<number> {
  if (!isPostgresUrl()) return mysqlDb.createEmployee(data as any);
  const db = pg();
  if (!db) throw new Error("PostgreSQL database not available");
  await ensureTables();
  const rows = await db`
    insert into employees ("fullName", email, phone, "passwordHash", role, permissions, department, "hireDate", notes)
    values (${data.fullName}, ${data.email.toLowerCase()}, ${data.phone || null}, ${hashPassword(data.password)}, ${data.role}, ${data.permissions || null}, ${data.department || null}, ${data.hireDate || null}, ${data.notes || null})
    returning id`;
  return Number(rows[0].id);
}

export async function updateEmployee(id: number, data: {
  fullName?: string;
  email?: string;
  phone?: string;
  password?: string;
  role?: EmployeeRole;
  permissions?: string;
  status?: EmployeeStatus;
  department?: string;
  notes?: string;
}): Promise<void> {
  if (!isPostgresUrl()) return mysqlDb.updateEmployee(id, data as any);
  const db = pg();
  if (!db) throw new Error("PostgreSQL database not available");
  await ensureTables();
  const existing: any = await getEmployeeById(id);
  if (!existing) return;
  await db`
    update employees set
      "fullName" = ${data.fullName ?? existing.fullName},
      email = ${data.email ? data.email.toLowerCase() : existing.email},
      phone = ${data.phone !== undefined ? data.phone : existing.phone},
      "passwordHash" = ${data.password !== undefined ? hashPassword(data.password) : existing.passwordHash},
      role = ${data.role ?? existing.role},
      permissions = ${data.permissions !== undefined ? data.permissions : existing.permissions},
      status = ${data.status ?? existing.status},
      department = ${data.department !== undefined ? data.department : existing.department},
      notes = ${data.notes !== undefined ? data.notes : existing.notes},
      "updatedAt" = now()
    where id = ${id}`;
}

export async function deleteEmployee(id: number): Promise<void> {
  if (!isPostgresUrl()) return mysqlDb.deleteEmployee(id);
  const db = pg();
  if (!db) throw new Error("PostgreSQL database not available");
  await ensureTables();
  await db`delete from employees where id = ${id}`;
}

export async function updateEmployeeLastLogin(id: number): Promise<void> {
  if (!isPostgresUrl()) return mysqlDb.updateEmployeeLastLogin(id);
  const db = pg();
  if (!db) return;
  await ensureTables();
  await db`update employees set "lastLogin" = now(), "updatedAt" = now() where id = ${id}`;
}

export async function addLoginLog(data: {
  identifier: string;
  accountType: "admin" | "employee";
  success: boolean;
  ipAddress?: string;
  userAgent?: string;
  failureReason?: string;
}): Promise<void> {
  if (!isPostgresUrl()) return mysqlDb.addLoginLog(data);
  const db = pg();
  if (!db) return;
  await ensureTables();
  await db`insert into login_logs (identifier, "accountType", success, "ipAddress", "userAgent", "failureReason") values (${data.identifier}, ${data.accountType}, ${data.success}, ${data.ipAddress || null}, ${data.userAgent || null}, ${data.failureReason || null})`;
}

export async function getLoginLogs(limit = 50): Promise<LoginLog[]> {
  if (!isPostgresUrl()) return mysqlDb.getLoginLogs(limit);
  const db = pg();
  if (!db) return [];
  await ensureTables();
  const rows = await db`select * from login_logs order by "createdAt" desc limit ${limit}`;
  return rows.map(log);
}
